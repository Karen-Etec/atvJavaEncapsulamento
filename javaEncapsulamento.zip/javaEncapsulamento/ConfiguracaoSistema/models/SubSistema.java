/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.etec.ConfiguracaoSistema.model;

/**
 *
 * @author musas
 */
public class SubSistema extends ConfiguracaoSistema {
    public SubSistema(String versaoSistema) {
        super(versaoSistema);
    }
}
    
    
