/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package br.edu.etec.ConfiguracaoSistema.model;

/**
 *
 * @author musas
 */
public class ConfiguracaoSistema {
    protected String versaoSistema;
    
    public ConfiguracaoSistema(String versaoSistema) {
        this.versaoSistema = versaoSistema;
    }
}
